"""
Strip Test Fail Pattern — 推論腳本 (使用 train_fail_pattern_stage2.py 訓練好的模型)
=====================================================================

讀取 train_fail_pattern_stage2.py 存下的 .pt 模型檔，對新的 Stage 1/2 匯出
JSON（可以是尚未標記的新 log，也可以是已標記的用來覆核）逐 strip 做預測，
輸出每個 strip 的預測類別與各類別機率，方便和 Stage 2 規則式判斷（路線 A）
或人工標記互相對照。

執行範例：
    python predict_fail_pattern.py --model ./models/fail_pattern_mlp.pt --input new_dataset.json
    python predict_fail_pattern.py --model ./models/fail_pattern_cnn.pt --input new_dataset.json --output predictions.csv
"""

import argparse
import csv
import json
import os

import numpy as np
import torch
import torch.nn as nn

ITEM_KEYS = ["VTH", "VFSD", "IPD_10V", "IDSS1", "IDSS2", "IDSS3"]
GRID_CHANNELS = ["pass", "nodata"] + [f"fail_{k}" for k in ITEM_KEYS]


class TabularMLP(nn.Module):
    def __init__(self, in_dim, num_classes, hidden=32):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden), nn.ReLU(), nn.Dropout(0.3),
            nn.Linear(hidden, hidden // 2), nn.ReLU(), nn.Dropout(0.2),
            nn.Linear(hidden // 2, num_classes),
        )

    def forward(self, x):
        return self.net(x)


class GridCNN(nn.Module):
    def __init__(self, in_channels, num_classes):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(in_channels, 16, 3, padding=1), nn.BatchNorm2d(16), nn.ReLU(),
            nn.Conv2d(16, 32, 3, padding=1), nn.BatchNorm2d(32), nn.ReLU(),
            nn.AdaptiveAvgPool2d(1),
        )
        self.classifier = nn.Sequential(
            nn.Flatten(), nn.Dropout(0.3),
            nn.Linear(32, num_classes),
        )

    def forward(self, x):
        return self.classifier(self.features(x))


def strip_to_feature_vector(strip, feature_keys):
    f = strip.get("features", {}) or {}
    G = strip.get("gridSide") or 13
    vec = [float(f.get(k, 0.0) or 0.0) for k in feature_keys]
    vec.append(float(f.get("bboxW", 0)) / G)
    vec.append(float(f.get("bboxH", 0)) / G)
    item_rate = f.get("itemFailRate", {}) or {}
    for k in ITEM_KEYS:
        vec.append(float(item_rate.get(k, 0.0) or 0.0))
    return np.array(vec, dtype=np.float32)


def strip_to_grid_tensor(strip):
    grid = strip.get("grid")
    G = strip.get("gridSide") or 13
    n_ch = len(GRID_CHANNELS)
    tensor = np.zeros((n_ch, G, G), dtype=np.float32)
    if not grid:
        tensor[GRID_CHANNELS.index("nodata")] = 1.0
        return tensor
    for r, row in enumerate(grid):
        for c, cell in enumerate(row):
            s = cell.get("s", "nodata")
            if s == "pass":
                tensor[GRID_CHANNELS.index("pass"), r, c] = 1.0
            elif s == "fail":
                item = cell.get("item")
                ch_name = f"fail_{item}" if item in ITEM_KEYS else "fail_VTH"
                tensor[GRID_CHANNELS.index(ch_name), r, c] = 1.0
            else:
                tensor[GRID_CHANNELS.index("nodata"), r, c] = 1.0
    return tensor


def main():
    ap = argparse.ArgumentParser(description="用訓練好的模型對新 strip 做 fail pattern 預測")
    ap.add_argument("--model", required=True, help=".pt 模型檔路徑（train_fail_pattern_stage2.py 產生）")
    ap.add_argument("--input", required=True, help="Stage1/2 匯出的 Dataset JSON（要有 grid 才能用 CNN 模型）")
    ap.add_argument("--output", default=None, help="輸出 CSV 路徑，不指定則印在終端機")
    args = ap.parse_args()

    if not os.path.isfile(args.model):
        raise SystemExit(
            f"[錯誤] 找不到模型檔: {args.model}\n"
            f"  請確認路徑是否正確，並確認已經先執行過 train_fail_pattern_stage2.py 且有加上 --save-dir 參數"
            f"（沒有 --save-dir 的話不會存模型檔）。"
        )
    if not os.path.isfile(args.input):
        raise SystemExit(
            f"[錯誤] 找不到輸入檔案: {args.input}\n"
            f"  這裡要接你「實際的」Dataset JSON 檔案路徑（例如 Stage 1/2 匯出的"
            f" StripFailPattern_..._Dataset_....json），不是文件裡的範例檔名，請換成真正的檔案路徑再試一次。"
        )

    ckpt = torch.load(args.model, map_location="cpu", weights_only=False)
    kind = ckpt["kind"]
    labels = ckpt["labels"]
    num_classes = len(labels)

    with open(args.input, "r", encoding="utf-8") as f:
        data = json.load(f)
    strips = data.get("strips", [])
    if not strips:
        raise SystemExit("輸入檔案沒有 strips 陣列或是空的，請確認是不是拿錯檔案了。")

    if kind == "mlp":
        feature_keys = ckpt["feature_keys"]
        mean = np.array(ckpt["norm_stats"]["mean"], dtype=np.float32)
        std = np.array(ckpt["norm_stats"]["std"], dtype=np.float32)
        model = TabularMLP(in_dim=ckpt["in_dim"], num_classes=num_classes)
        X = np.stack([strip_to_feature_vector(s, feature_keys) for s in strips])
        X = (X - mean) / std
        X_t = torch.tensor(X, dtype=torch.float32)
    else:
        model = GridCNN(in_channels=ckpt["in_dim"], num_classes=num_classes)
        X = np.stack([strip_to_grid_tensor(s) for s in strips])
        X_t = torch.tensor(X, dtype=torch.float32)

    model.load_state_dict(ckpt["model_state"])
    model.eval()

    with torch.no_grad():
        logits = model(X_t)
        probs = torch.softmax(logits, dim=1).numpy()
        preds = probs.argmax(axis=1)

    rows = []
    for s, pred_idx, prob_row in zip(strips, preds, probs):
        row = {
            "lot": s.get("lot"), "slot": s.get("slot"),
            "predicted_label": labels[pred_idx],
            "confidence": float(prob_row[pred_idx]),
            "manual_label": s.get("manualLabel", ""),
        }
        for lab, p in zip(labels, prob_row):
            row[f"prob_{lab}"] = round(float(p), 4)
        rows.append(row)

    if args.output:
        with open(args.output, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)
        print(f"已輸出 {len(rows)} 筆預測結果至 {args.output}")
    else:
        for row in rows:
            print(f"{row['lot']}\tslot{row['slot']}\t預測: {row['predicted_label']}"
                  f"\t信心: {row['confidence']*100:.1f}%\t人工標記: {row['manual_label'] or '(無)'}")


if __name__ == "__main__":
    main()
