"""
Strip Test Fail Pattern — Stage 2 → Route B 模型訓練腳本 (PyTorch)
=====================================================================

這支腳本是 Stage 1 / Stage 2（瀏覽器 HTML 工具）之後的「路線 B」訓練步驟。
Stage 1/2 只能在瀏覽器 JavaScript 環境跑，無法執行 PyTorch；
本腳本才是真正離開瀏覽器、用 Python + PyTorch 訓練模型的地方。

輸入：Stage 2 匯出的「TrainReady」Dataset JSON
      （在 Stage 2 頁面勾選「排除 None」後匯出的
      StripFailPattern_Stage2_Dataset_TrainReady_YYYYMMDD.json）

支援兩種模型架構，可各自訓練或一次跑兩種比較：
  --model mlp   Tabular 特徵型：吃 Stage 1/2 算好的特徵向量（yield、fail rate、
                edge/center ratio、streak、cluster score…）。訓練快、可解釋性高，
                樣本數少時通常比 CNN 穩定。
  --model cnn   Image-based：直接吃 13×13 的 pass/fail/測試項 grid，保留完整空間
                資訊，理論上更適合學習複雜的空間樣態，但需要更多樣本才不會 overfit。
  --model both  兩種都訓練，最後印出對照表方便比較（預設）。

因為每個類別可能只有 10~30 筆標記樣本，樣本數太少，單一 train/val 切分結果會
很不穩定（切到哪幾筆當驗證集，準確率可能差很多）。所以本腳本用 **K-fold 交叉驗證**
（預設 5-fold，並依類別分層 stratified，確保每一折的類別比例接近整體），把 K 折
結果平均起來，才是比較可信的準確率估計。CNN 另外對每個訓練樣本做「水平/垂直翻轉」
的資料增強（見下方說明為什麼可以放心翻轉），變相把樣本數乘以最多 4 倍，緩解樣本
不足的問題。

安裝需求：
    pip install torch numpy scikit-learn

執行範例：
    python train_fail_pattern_stage2.py --input StripFailPattern_Stage2_Dataset_TrainReady_20260706.json
    python train_fail_pattern_stage2.py --input dataset.json --model cnn --epochs 80 --kfolds 5
    python train_fail_pattern_stage2.py --input dataset.json --model both --save-dir ./models

輸出：
    - 終端機印出每一折、每個 epoch 的訓練狀況（可用 --quiet 關掉）
    - K-fold 平均準確率、每類別 Precision/Recall/F1（sklearn classification_report）
    - 混淆矩陣（K 折加總）
    - 若指定 --save-dir，會把「用全部資料重新訓練一次」的最終模型存成 .pt，
      供之後對新 strip 做推論用（另附 predict_fail_pattern.py 範例腳本）
"""

import argparse
import json
import sys
from collections import Counter

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader, Subset

try:
    from sklearn.model_selection import StratifiedKFold
    from sklearn.metrics import classification_report, confusion_matrix
except ImportError:
    sys.exit("缺少 scikit-learn，請先執行: pip install scikit-learn")


# ══════════════════════════════════════════════════════════════════════
# 常數：對應 Stage 1 / Stage 2 的實際 schema
# ══════════════════════════════════════════════════════════════════════
ITEM_KEYS = ["VTH", "VFSD", "IPD_10V", "IDSS1", "IDSS2", "IDSS3"]

# Tabular 模型使用的特徵欄位（對應 Stage2 features 物件）
FEATURE_KEYS = [
    "yield",
    "edgeFailRatio", "interiorFailRatio", "centerFailRatio",
    "maxRowFailFrac", "maxColFailFrac",
    "clusterScore", "bboxDensity",
]
# bboxW / bboxH 用相對 gridSide 的比例，而非絕對值，避免不同 grid 尺寸互相干擾
# itemFailRate 逐測試項攤平成獨立欄位

GRID_CHANNELS = ["pass", "nodata"] + [f"fail_{k}" for k in ITEM_KEYS]  # one-hot 通道


# ══════════════════════════════════════════════════════════════════════
# 資料載入與轉換
# ══════════════════════════════════════════════════════════════════════
def load_dataset(path):
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    strips = data.get("strips", [])
    strips = [s for s in strips if s.get("manualLabel")]  # 只保留有人工標記的
    if not strips:
        sys.exit("輸入檔案裡沒有任何已標記（manualLabel 非空）的 strip，無法訓練。")
    return strips


def build_label_map(strips):
    labels = sorted({s["manualLabel"] for s in strips})
    label2idx = {lab: i for i, lab in enumerate(labels)}
    return labels, label2idx


def strip_to_feature_vector(strip):
    """Tabular 模型的輸入：把 Stage2 features 物件攤平成固定長度向量。"""
    f = strip.get("features", {}) or {}
    G = strip.get("gridSide") or 13
    vec = [float(f.get(k, 0.0) or 0.0) for k in FEATURE_KEYS]
    vec.append(float(f.get("bboxW", 0)) / G)
    vec.append(float(f.get("bboxH", 0)) / G)
    item_rate = f.get("itemFailRate", {}) or {}
    for k in ITEM_KEYS:
        vec.append(float(item_rate.get(k, 0.0) or 0.0))
    return np.array(vec, dtype=np.float32)


def strip_to_grid_tensor(strip):
    """
    CNN 模型的輸入：把 grid（Stage1/2 匯出的 13x13 pass/fail/nodata 陣列）
    轉成 (channels, G, G) 的 one-hot 張量。
    grid[row_idx][col_idx] 對應 y = G - row_idx, x = col_idx + 1（與 Stage1/2 一致），
    但對 CNN 來說絕對座標不重要，直接照原始陣列順序當成影像即可。
    """
    grid = strip.get("grid")
    G = strip.get("gridSide") or 13
    n_ch = len(GRID_CHANNELS)
    tensor = np.zeros((n_ch, G, G), dtype=np.float32)
    if not grid:
        # 沒有 grid（例如來自純 CSV 匯入），全部標成 nodata
        tensor[GRID_CHANNELS.index("nodata")] = 1.0
        return tensor
    for r, row in enumerate(grid):
        for c, cell in enumerate(row):
            s = cell.get("s", "nodata")
            if s == "pass":
                tensor[GRID_CHANNELS.index("pass"), r, c] = 1.0
            elif s == "fail":
                item = cell.get("item")
                ch_name = f"fail_{item}" if item in ITEM_KEYS else "fail_VTH"
                tensor[GRID_CHANNELS.index(ch_name), r, c] = 1.0
            else:
                tensor[GRID_CHANNELS.index("nodata"), r, c] = 1.0
    return tensor


# 允許的資料增強：哪些幾何變換不會改變 pattern 的「語意」。
# - 90 度旋轉會把 Row-Streak 變成 Column-Streak，兩者是不同類別，故不可旋轉。
# - 水平翻轉 / 垂直翻轉都不會改變「這是哪一種樣態」的判斷
#   （Row-Streak 翻轉後仍是 Row-Streak，Edge-Ring/Center/Cluster/Full-Fail/Random
#   本身具有對稱性，翻轉不影響語意；Corner 翻轉後仍是 Corner，只是換一個角落）。
def augment_flips(tensor):
    variants = [tensor]
    variants.append(tensor[:, :, ::-1].copy())       # 水平翻轉
    variants.append(tensor[:, ::-1, :].copy())       # 垂直翻轉
    variants.append(tensor[:, ::-1, ::-1].copy())    # 水平+垂直
    return variants


class TabularDataset(Dataset):
    def __init__(self, X, y):
        self.X = torch.tensor(X, dtype=torch.float32)
        self.y = torch.tensor(y, dtype=torch.long)

    def __len__(self):
        return len(self.y)

    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]


class GridDataset(Dataset):
    """CNN 用資料集；訓練模式下自動套用水平/垂直翻轉增強。"""
    def __init__(self, tensors, labels, augment=False):
        self.samples = []
        for t, lab in zip(tensors, labels):
            if augment:
                for v in augment_flips(t):
                    self.samples.append((v, lab))
            else:
                self.samples.append((t, lab))

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        t, lab = self.samples[idx]
        return torch.tensor(t, dtype=torch.float32), torch.tensor(lab, dtype=torch.long)


# ══════════════════════════════════════════════════════════════════════
# 模型定義（刻意保持小型，避免樣本數少時嚴重 overfit）
# ══════════════════════════════════════════════════════════════════════
class TabularMLP(nn.Module):
    def __init__(self, in_dim, num_classes, hidden=32):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden), nn.ReLU(), nn.Dropout(0.3),
            nn.Linear(hidden, hidden // 2), nn.ReLU(), nn.Dropout(0.2),
            nn.Linear(hidden // 2, num_classes),
        )

    def forward(self, x):
        return self.net(x)


class GridCNN(nn.Module):
    def __init__(self, in_channels, num_classes):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(in_channels, 16, 3, padding=1), nn.BatchNorm2d(16), nn.ReLU(),
            nn.Conv2d(16, 32, 3, padding=1), nn.BatchNorm2d(32), nn.ReLU(),
            nn.AdaptiveAvgPool2d(1),
        )
        self.classifier = nn.Sequential(
            nn.Flatten(), nn.Dropout(0.3),
            nn.Linear(32, num_classes),
        )

    def forward(self, x):
        return self.classifier(self.features(x))


# ══════════════════════════════════════════════════════════════════════
# 訓練 / 評估
# ══════════════════════════════════════════════════════════════════════
def class_weights_from_labels(y, num_classes):
    counts = np.bincount(y, minlength=num_classes).astype(np.float32)
    counts[counts == 0] = 1.0
    weights = counts.sum() / (num_classes * counts)
    return torch.tensor(weights, dtype=torch.float32)


def train_one_fold(model, train_loader, val_loader, device, epochs, lr, class_weights, quiet):
    model.to(device)
    criterion = nn.CrossEntropyLoss(weight=class_weights.to(device))
    optimizer = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=1e-4)

    for epoch in range(1, epochs + 1):
        model.train()
        total_loss = 0.0
        for xb, yb in train_loader:
            xb, yb = xb.to(device), yb.to(device)
            optimizer.zero_grad()
            out = model(xb)
            loss = criterion(out, yb)
            loss.backward()
            optimizer.step()
            total_loss += loss.item() * xb.size(0)
        if not quiet and (epoch % max(1, epochs // 5) == 0 or epoch == epochs):
            avg_loss = total_loss / len(train_loader.dataset)
            print(f"      epoch {epoch:>3}/{epochs}  train_loss={avg_loss:.4f}")

    model.eval()
    all_preds, all_true = [], []
    with torch.no_grad():
        for xb, yb in val_loader:
            xb = xb.to(device)
            out = model(xb)
            preds = out.argmax(dim=1).cpu().numpy()
            all_preds.extend(preds.tolist())
            all_true.extend(yb.numpy().tolist())
    return all_true, all_preds


def run_kfold(kind, strips, labels, label2idx, args, device):
    y_all = np.array([label2idx[s["manualLabel"]] for s in strips])
    num_classes = len(labels)
    n_splits = min(args.kfolds, min(Counter(y_all).values()))
    if n_splits < 2:
        print(f"[{kind}] 警告：某個類別樣本數 < 2，無法做 {args.kfolds}-fold，"
              f"改用 {max(2, n_splits)}-fold。樣本數更多後建議重跑。")
        n_splits = max(2, n_splits)

    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=args.seed)

    if kind == "mlp":
        X_all = np.stack([strip_to_feature_vector(s) for s in strips])
        mean, std = X_all.mean(axis=0), X_all.std(axis=0) + 1e-6
    else:
        X_all = np.stack([strip_to_grid_tensor(s) for s in strips])

    fold_true, fold_pred = [], []
    print(f"\n{'='*70}\n模型：{kind.upper()}　|　樣本數：{len(strips)}　|　類別數：{num_classes}　|　{n_splits}-fold 交叉驗證\n{'='*70}")

    for fold, (train_idx, val_idx) in enumerate(skf.split(X_all, y_all), 1):
        print(f"\n  -- Fold {fold}/{n_splits} --")
        y_train, y_val = y_all[train_idx], y_all[val_idx]

        if kind == "mlp":
            Xtr = (X_all[train_idx] - mean) / std
            Xval = (X_all[val_idx] - mean) / std
            train_ds = TabularDataset(Xtr, y_train)
            val_ds = TabularDataset(Xval, y_val)
            model = TabularMLP(in_dim=X_all.shape[1], num_classes=num_classes)
        else:
            train_ds = GridDataset(X_all[train_idx], y_train, augment=True)
            val_ds = GridDataset(X_all[val_idx], y_val, augment=False)
            model = GridCNN(in_channels=X_all.shape[1], num_classes=num_classes)

        train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True)
        val_loader = DataLoader(val_ds, batch_size=args.batch_size, shuffle=False)

        cw = class_weights_from_labels(y_train, num_classes)
        true, pred = train_one_fold(model, train_loader, val_loader, device,
                                     args.epochs, args.lr, cw, args.quiet)
        fold_true.extend(true)
        fold_pred.extend(pred)
        fold_acc = np.mean(np.array(true) == np.array(pred))
        print(f"      fold {fold} 驗證準確率: {fold_acc*100:.1f}%")

    print(f"\n---- {kind.upper()} 總結（{n_splits} 折加總）----")
    overall_acc = np.mean(np.array(fold_true) == np.array(fold_pred))
    print(f"整體 K-fold 準確率: {overall_acc*100:.2f}%\n")
    print(classification_report(fold_true, fold_pred, target_names=labels,
                                 labels=list(range(num_classes)), zero_division=0))
    print("混淆矩陣（列=實際, 欄=預測）:")
    cm = confusion_matrix(fold_true, fold_pred, labels=list(range(num_classes)))
    header = "        " + " ".join(f"{l[:6]:>6}" for l in labels)
    print(header)
    for i, row in enumerate(cm):
        print(f"{labels[i][:6]:>6}  " + " ".join(f"{v:>6}" for v in row))

    return overall_acc


def train_final_model(kind, strips, labels, label2idx, args, device, save_dir):
    """用全部資料重新訓練一次，作為最終要儲存/部署的模型。"""
    y_all = np.array([label2idx[s["manualLabel"]] for s in strips])
    num_classes = len(labels)

    if kind == "mlp":
        X_all = np.stack([strip_to_feature_vector(s) for s in strips])
        mean, std = X_all.mean(axis=0), X_all.std(axis=0) + 1e-6
        Xn = (X_all - mean) / std
        ds = TabularDataset(Xn, y_all)
        model = TabularMLP(in_dim=X_all.shape[1], num_classes=num_classes)
        norm_stats = {"mean": mean.tolist(), "std": std.tolist()}
    else:
        X_all = np.stack([strip_to_grid_tensor(s) for s in strips])
        ds = GridDataset(X_all, y_all, augment=True)
        model = GridCNN(in_channels=X_all.shape[1], num_classes=num_classes)
        norm_stats = {}

    loader = DataLoader(ds, batch_size=args.batch_size, shuffle=True)
    cw = class_weights_from_labels(y_all, num_classes)
    model.to(device)
    criterion = nn.CrossEntropyLoss(weight=cw.to(device))
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=1e-4)
    for epoch in range(1, args.epochs + 1):
        model.train()
        for xb, yb in loader:
            xb, yb = xb.to(device), yb.to(device)
            optimizer.zero_grad()
            loss = criterion(model(xb), yb)
            loss.backward()
            optimizer.step()

    import os
    os.makedirs(save_dir, exist_ok=True)
    out_path = os.path.join(save_dir, f"fail_pattern_{kind}.pt")
    torch.save({
        "model_state": model.state_dict(),
        "kind": kind,
        "labels": labels,
        "feature_keys": FEATURE_KEYS if kind == "mlp" else None,
        "grid_channels": GRID_CHANNELS if kind == "cnn" else None,
        "norm_stats": norm_stats,
        "in_dim": X_all.shape[1] if kind == "mlp" else X_all.shape[1],
    }, out_path)
    print(f"[{kind}] 最終模型已存至: {out_path}")


# ══════════════════════════════════════════════════════════════════════
# CLI
# ══════════════════════════════════════════════════════════════════════
def main():
    ap = argparse.ArgumentParser(description="Strip Test Fail Pattern - Stage2 PyTorch 訓練腳本")
    ap.add_argument("--input", required=True, help="Stage2 匯出的 TrainReady Dataset JSON 路徑")
    ap.add_argument("--model", choices=["mlp", "cnn", "both"], default="both")
    ap.add_argument("--epochs", type=int, default=60)
    ap.add_argument("--kfolds", type=int, default=5)
    ap.add_argument("--batch-size", type=int, default=16)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--save-dir", default=None, help="若指定，訓練完會用全部資料重訓一次並存模型檔到此目錄")
    ap.add_argument("--quiet", action="store_true", help="不印每個 epoch 的訓練 loss")
    args = ap.parse_args()

    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"使用裝置: {device}")

    strips = load_dataset(args.input)
    labels, label2idx = build_label_map(strips)
    counts = Counter(s["manualLabel"] for s in strips)
    print(f"\n讀取到 {len(strips)} 筆已標記樣本，共 {len(labels)} 個類別：")
    for lab in labels:
        print(f"  {lab:<20} {counts[lab]:>4} 筆")
    if min(counts.values()) < 5:
        print("\n[提醒] 有類別樣本數 < 5，K-fold 結果僅供參考，建議持續累積標記後重跑。")

    kinds = ["mlp", "cnn"] if args.model == "both" else [args.model]
    results = {}
    for kind in kinds:
        acc = run_kfold(kind, strips, labels, label2idx, args, device)
        results[kind] = acc
        if args.save_dir:
            train_final_model(kind, strips, labels, label2idx, args, device, args.save_dir)

    if len(results) > 1:
        print(f"\n{'='*70}\n模型比較（K-fold 平均準確率）\n{'='*70}")
        for kind, acc in results.items():
            print(f"  {kind.upper():<6} : {acc*100:.2f}%")
        best = max(results, key=results.get)
        print(f"\n目前樣本量下表現較好的是: {best.upper()}"
              f"（樣本數少時 MLP 通常較穩定，等標記數增加後可再重跑比較）")


if __name__ == "__main__":
    main()
