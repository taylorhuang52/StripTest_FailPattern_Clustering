# Strip Test Fail Pattern — Stage 2 → 路線 B PyTorch 訓練套件

這個資料夾是 Stage 1 / Stage 2（瀏覽器 HTML 工具）之後的「路線 B」訓練步驟。
Stage 1/2 只能在瀏覽器 JavaScript 環境跑，無法執行 PyTorch；這裡的 Python 腳本
才是真正離開瀏覽器、用 PyTorch 訓練模型的地方。

## 檔案說明

- `train_fail_pattern_stage2.py` — 訓練腳本。讀取 Stage 2 匯出的「TrainReady」
  Dataset JSON，可訓練 Tabular MLP、Image-based CNN，或兩者一起訓練比較。
  用 K-fold 交叉驗證評估準確率（因為每類別樣本數通常不多，單一 train/val
  切分結果不穩定）。
- `predict_fail_pattern.py` — 推論腳本。讀取訓練好的 `.pt` 模型，對新的
  Stage 1/2 匯出 JSON 逐 strip 預測 fail pattern 類別。
- `requirements.txt` — Python 套件需求。

## 安裝

```bash
pip install -r requirements.txt
```

## 使用方式

1. 在 Stage 2 頁面完成規則式分類與人工標記覆核後，勾選「排除 None」匯出
   `StripFailPattern_Stage2_Dataset_TrainReady_YYYYMMDD.json`。
2. 執行訓練：
   ```bash
   python train_fail_pattern_stage2.py --input StripFailPattern_Stage2_Dataset_TrainReady_YYYYMMDD.json --model both --save-dir ./models
   ```
3. 對新資料做推論：
   ```bash
   python predict_fail_pattern.py --model ./models/fail_pattern_mlp.pt --input new_dataset.json --output predictions.csv
   ```

完整參數說明、模型架構、資料增強邏輯、每個門檻/超參數的意義，請見
`train_fail_pattern_stage2.py` 檔案開頭的說明文字，或 Stage 2 頁面下方的
「模型訓練套件」與「訓練超參數」區段（會即時產生對應的指令）。

## 硬體建議與預估時間

目前資料集規模（每類 10~30 筆標記樣本、13×13 grid、6 個測試項）非常小，
**不需要 GPU**，一般筆電/桌機的 CPU 就足夠：

- Tabular MLP（60 epochs × 5-fold）：約 10~15 秒
- Image-based CNN（60 epochs × 5-fold）：約 1~1.5 分鐘
- 兩者一起跑 + 存最終模型：約 2~3 分鐘

（以上為單核心 CPU、無 GPU 環境下實測的參考值；多核心 CPU 或有 GPU 會更快，
但以現在的資料量與模型規模來說幫助有限，GPU 的優勢要等資料量明顯變大、
模型變複雜之後才會顯現。）
